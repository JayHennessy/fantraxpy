# Fantrax API Client
This is an unofficial Fantrax API client.